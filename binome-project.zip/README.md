# BINÔME STUDIO · PAULINE & MATH

Socle initial d'une application web responsive pour iPhone, iPad et ordinateur.

## Déjà présent
- Identité visuelle anthracite, ivoire et or doux.
- Navigation des six modules.
- Sélecteur de profil de démonstration Pauline / Math (pas encore de vrais comptes).
- Calculateur matière de démonstration avec marge sur prix de vente.
- Schéma de départ Supabase pour profils, matières premières et recettes.

## Lancer
Prérequis : Node.js 20+.
```bash
npm install
npm run dev
```
Ouvrir ensuite http://localhost:3000.

## Base cloud
1. Créer un projet Supabase.
2. Copier `.env.example` en `.env.local` et renseigner URL + clé anon.
3. Exécuter `supabase/schema.sql` dans le SQL Editor.
4. Configurer les politiques de sécurité RLS et les comptes avant d'importer des données réelles.

## Déploiement
Déploiement possible sur Vercel ou plateforme compatible Next.js après configuration du projet et des variables d'environnement.

## Limites honnêtes de la version 0.1
Ce n'est pas encore une application hébergée. Les modules Recettes, Matières premières, Fiches techniques et Production sont des écrans de départ. Le calculateur ne prend pas encore en compte la main-d’œuvre, les emballages, les frais généraux ni la TVA. Le profil sélectionné est uniquement visuel. Aucune donnée n'est encore synchronisée.


## Préparation PWA
Le projet comprend maintenant un manifeste, une icône, et un service worker avec mise en cache de base. L'installation PWA nécessite un hébergement HTTPS (localhost accepté pour les tests). Le cache hors ligne reste limité à l'enveloppe de l'application : les données métiers ne sont pas encore synchronisées ni disponibles hors ligne tant que la base cloud et la stratégie de stockage ne sont pas terminées.

### Installer sur iPhone
Une fois l'application publiée en HTTPS :
1. Ouvrir son adresse dans Safari.
2. Appuyer sur Partager.
3. Choisir « Sur l’écran d’accueil ».
4. Valider l’ajout.

## Version 0.3 — connexion et recettes cloud
- Connexion individuelle par e-mail et mot de passe via Supabase Auth.
- Lecture de la bibliothèque `public.recipes` après connexion.
- Création des recettes dans `public.recipes` avec `created_by` lié au compte connecté.
- Déconnexion sécurisée via Supabase Auth.

### Configuration nécessaire
Créer `.env.local` à partir de `.env.example`, puis renseigner l'URL du projet Supabase et la clé **anon/public** du projet. Ne jamais utiliser la clé `service_role` dans l'application.
Les deux comptes doivent exister dans Supabase Auth et les politiques RLS de `public.recipes` doivent autoriser les deux comptes.

## Version 0.4 — Bibliothèque des matières premières

Cette version ajoute la lecture et la création de matières premières dans `public.ingredients`, avec les colonnes déjà présentes dans la base : `name`, `manufacturer`, `supplier`, `reference`, `package_quantity`, `package_unit`, `package_price`, `currency`, `vat_included`, `notes` et `created_by`. Les recettes restent connectées à `public.recipes`.

Variables Vercel requises : `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Après modification de ces variables, un nouveau déploiement est nécessaire. La clé `anon`/publishable est destinée au client ; ne jamais mettre une clé `service_role` dans une variable `NEXT_PUBLIC_`.
